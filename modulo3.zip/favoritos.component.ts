// ============================================================
// src/app/pages/favoritos/favoritos.component.ts
// Lista de favoritos + botón "Leer Ahora" → Redux dispatch
// ============================================================
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';

import { FavoritosService } from '../../core/services/favoritos.service';
import { Libro } from '../../core/services/libros.service';
import { leerAhora } from '../../store/libros.actions';

@Component({
  selector: 'app-favoritos',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './favoritos.component.html',
  styleUrls: ['./favoritos.component.scss'],
})
export class FavoritosComponent {

  favoritos$ = this.favoritosService.favoritos$;

  constructor(
    private favoritosService: FavoritosService,
    private store: Store
  ) {}

  quitarFavorito(libro: Libro): void {
    this.favoritosService.toggleFavorito(libro);
  }

  /** Despacha action a Redux Store */
  despacharLeerAhora(libro: Libro): void {
    this.store.dispatch(leerAhora({ libro }));
  }
}
