// ============================================================
// src/app/core/services/settings.service.ts
// Gestión del nombre de usuario con LocalStorage
// ============================================================
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AppSettings } from '../app-settings';

@Injectable({ providedIn: 'root' })
export class SettingsService {

  private readonly KEY = AppSettings.STORAGE_KEYS.USERNAME;

  private _username$ = new BehaviorSubject<string>(this.cargarUsername());
  username$ = this._username$.asObservable();

  get username(): string {
    return this._username$.getValue();
  }

  /** Guarda el nombre de usuario en LocalStorage */
  guardarUsername(nombre: string): void {
    localStorage.setItem(this.KEY, nombre);
    this._username$.next(nombre);
  }

  private cargarUsername(): string {
    return localStorage.getItem(this.KEY) ?? '';
  }
}
