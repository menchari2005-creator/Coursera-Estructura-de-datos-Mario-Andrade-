// ============================================================
// src/app/core/app-settings.ts
// Variable de configuración global (URL de Ngrok, etc.)
// ============================================================

export const AppSettings = {
  // 👇 Cambia esta URL por la de tu Ngrok al correr el servidor
  API_URL: 'http://localhost:3000',

  // Claves para LocalStorage / SessionStorage
  STORAGE_KEYS: {
    USERNAME: 'app_username',
    FAVORITOS: 'app_favoritos',
  },
};
