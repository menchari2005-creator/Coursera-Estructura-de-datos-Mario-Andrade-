// ============================================================
// src/app/core/services/favoritos.service.ts
// Gestión de favoritos con LocalStorage
// ============================================================
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Libro } from './libros.service';
import { AppSettings } from '../app-settings';

@Injectable({ providedIn: 'root' })
export class FavoritosService {

  private readonly KEY = AppSettings.STORAGE_KEYS.FAVORITOS;
  private _favoritos$ = new BehaviorSubject<Libro[]>(this.cargarDelStorage());

  /** Observable reactivo de favoritos */
  favoritos$ = this._favoritos$.asObservable();

  /** Retorna el array actual */
  get favoritos(): Libro[] {
    return this._favoritos$.getValue();
  }

  /** Agrega o quita un favorito (toggle) */
  toggleFavorito(libro: Libro): void {
    const actuales = this.favoritos;
    const index = actuales.findIndex(f => f.id === libro.id);
    const nuevos = index >= 0
      ? actuales.filter(f => f.id !== libro.id)
      : [...actuales, libro];

    this.guardarEnStorage(nuevos);
    this._favoritos$.next(nuevos);
  }

  /** Verifica si un libro está en favoritos */
  esFavorito(id: number): boolean {
    return this.favoritos.some(f => f.id === id);
  }

  // ── Helpers ──────────────────────────────────────────────
  private cargarDelStorage(): Libro[] {
    try {
      const raw = localStorage.getItem(this.KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  private guardarEnStorage(libros: Libro[]): void {
    localStorage.setItem(this.KEY, JSON.stringify(libros));
  }
}
