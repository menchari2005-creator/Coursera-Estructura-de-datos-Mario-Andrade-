# Módulo 3 — Almacenamiento e Integración Redux

Aplicación completa: **Backend Express** + **Frontend Angular 17** con NgRx (Redux).

---

## Estructura del proyecto

```
module3/
├── backend/
│   ├── server.js          ← API Express (WebService GET con querystring)
│   └── package.json
│
└── frontend-angular/
    └── src/
        ├── styles.scss                    ← Estilos globales
        └── app/
            ├── app.component.ts           ← Shell + Tab Bar de navegación
            ├── app.config.ts              ← Providers: Router, HttpClient, NgRx
            ├── app.routes.ts              ← Rutas: /home /favoritos /settings
            │
            ├── core/
            │   ├── app-settings.ts        ← [Req. 3] URL de Ngrok configurable
            │   └── services/
            │       ├── libros.service.ts  ← [Req. 4] HTTP Service Angular
            │       ├── favoritos.service.ts ← [Req. 7,8] LocalStorage
            │       └── settings.service.ts  ← [Req. 5,6] LocalStorage username
            │
            ├── store/
            │   ├── libros.actions.ts      ← [Req. 9] Actions: leerAhora
            │   ├── libros.reducer.ts      ← NgRx Reducer
            │   └── libros.selectors.ts    ← [Req.10] selectLeerAhora
            │
            └── pages/
                ├── home/                  ← [Req. 1,2,10] Búsqueda + Leer Ahora
                ├── favoritos/             ← [Req. 8,9] Lista + "Leer ahora"
                └── settings/             ← [Req. 5,6] Username + API URL
```

---

## Cobertura de requisitos

| # | Requisito | Archivo clave |
|---|-----------|---------------|
| 1 | API Express GET con querystring | `backend/server.js` |
| 2 | Listado + formulario de búsqueda filtrado | `pages/home/` |
| 3 | Variable configurable URL Ngrok | `core/app-settings.ts` |
| 4 | Service Angular para llamadas HTTP | `core/services/libros.service.ts` |
| 5 | Settings con LocalStorage (leer username) | `pages/settings/` + `services/settings.service.ts` |
| 6 | Editar y persistir username | `pages/settings/` |
| 7 | Ícono favorito en listado | `pages/home/home.component.html` |
| 8 | Favoritos listados | `pages/favoritos/` |
| 9 | "Leer ahora" despacha action Redux | `pages/favoritos/favoritos.component.ts` |
|10 | Pantalla principal muestra lista Redux reactiva | `pages/home/home.component.ts` + selectors |

---

## Instalación y ejecución

### 1. Backend Express

```bash
cd module3/backend
npm install
npm start
# → API corriendo en http://localhost:3000

# Pruebas rápidas:
curl "http://localhost:3000/api/libros"
curl "http://localhost:3000/api/libros?q=sol"
curl "http://localhost:3000/api/libros?genero=Ficción"
```

### 2. Ngrok (para exponer la API al móvil)

```bash
ngrok http 3000
# Copia la URL https://xxxx.ngrok.io
# Pégala en: frontend-angular/src/app/core/app-settings.ts
#   API_URL: 'https://xxxx.ngrok.io'
```

### 3. Frontend Angular

```bash
cd module3/frontend-angular
npm install
ng serve
# → http://localhost:4200
```

---

## API Reference

### `GET /api/libros`

| Parámetro | Tipo | Descripción |
|-----------|------|-------------|
| `q` | string | Filtra por título o autor |
| `genero` | string | Filtra por género exacto |

**Respuesta:**
```json
{
  "total": 2,
  "query": { "q": "sol", "genero": "" },
  "data": [
    { "id": 2, "titulo": "Cien Años de Soledad", "autor": "...", "genero": "Realismo Mágico", "anio": 1967 }
  ]
}
```

---

## Flujo Redux (NgRx)

```
[Favoritos] usuario clica "Leer ahora"
      ↓
  dispatch(leerAhora({ libro }))
      ↓
  librosReducer → agrega a state.leerAhora[]
      ↓
  [Home] store.select(selectLeerAhora) → lista reactiva actualizada
```

---

## LocalStorage Keys

| Clave | Contenido | Usado en |
|-------|-----------|----------|
| `app_username` | `"Juan"` | SettingsService |
| `app_favoritos` | `[{id,titulo,...}]` | FavoritosService |
