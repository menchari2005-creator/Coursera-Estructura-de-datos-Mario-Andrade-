// ============================================================
// src/app/store/libros.actions.ts
// NgRx Actions para Redux
// ============================================================
import { createAction, props } from '@ngrx/store';
import { Libro } from '../core/services/libros.service';

/** Acción despachada desde "Leer ahora" en Favoritos */
export const leerAhora = createAction(
  '[Favoritos] Leer Ahora',
  props<{ libro: Libro }>()
);

/** Quitar de la lista "Leer ahora" */
export const quitarLeerAhora = createAction(
  '[LeerAhora] Quitar',
  props<{ id: number }>()
);
