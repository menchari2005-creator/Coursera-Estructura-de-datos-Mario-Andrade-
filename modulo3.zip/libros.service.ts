// ============================================================
// src/app/core/services/libros.service.ts
// Service Angular — responsable de todas las llamadas HTTP
// ============================================================
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppSettings } from '../app-settings';

export interface Libro {
  id: number;
  titulo: string;
  autor: string;
  genero: string;
  anio: number;
}

export interface LibrosResponse {
  total: number;
  query: { q: string; genero: string };
  data: Libro[];
}

@Injectable({ providedIn: 'root' })
export class LibrosService {

  private readonly baseUrl = AppSettings.API_URL;

  constructor(private http: HttpClient) {}

  /** Busca libros con filtrado opcional por texto y género */
  buscar(q: string = '', genero: string = ''): Observable<LibrosResponse> {
    let params = new HttpParams();
    if (q)      params = params.set('q', q);
    if (genero) params = params.set('genero', genero);

    return this.http.get<LibrosResponse>(`${this.baseUrl}/api/libros`, { params });
  }

  /** Obtiene un libro por ID */
  obtenerPorId(id: number): Observable<Libro> {
    return this.http.get<Libro>(`${this.baseUrl}/api/libros/${id}`);
  }
}
