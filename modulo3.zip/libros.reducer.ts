// ============================================================
// src/app/store/libros.reducer.ts
// NgRx Reducer
// ============================================================
import { createReducer, on } from '@ngrx/store';
import { leerAhora, quitarLeerAhora } from './libros.actions';
import { Libro } from '../core/services/libros.service';

export interface LibrosState {
  leerAhora: Libro[];
}

export const initialState: LibrosState = {
  leerAhora: [],
};

export const librosReducer = createReducer(
  initialState,

  on(leerAhora, (state, { libro }) => {
    // Evitar duplicados
    const yaExiste = state.leerAhora.some(l => l.id === libro.id);
    if (yaExiste) return state;
    return { ...state, leerAhora: [...state.leerAhora, libro] };
  }),

  on(quitarLeerAhora, (state, { id }) => ({
    ...state,
    leerAhora: state.leerAhora.filter(l => l.id !== id),
  }))
);
