// ============================================================
// MÓDULO 3 — Backend Express
// WebService GET con filtrado por querystring
// ============================================================
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// ──────────────────────────────────────────────
// Dataset de ejemplo: libros (puedes reemplazar)
// ──────────────────────────────────────────────
const libros = [
  { id: 1, titulo: 'El Principito',          autor: 'Antoine de Saint-Exupéry', genero: 'Ficción',    anio: 1943 },
  { id: 2, titulo: 'Cien Años de Soledad',   autor: 'Gabriel García Márquez',   genero: 'Realismo Mágico', anio: 1967 },
  { id: 3, titulo: '1984',                   autor: 'George Orwell',            genero: 'Distopía',    anio: 1949 },
  { id: 4, titulo: 'Don Quijote',            autor: 'Miguel de Cervantes',      genero: 'Clásico',     anio: 1605 },
  { id: 5, titulo: 'Rayuela',                autor: 'Julio Cortázar',           genero: 'Ficción',     anio: 1963 },
  { id: 6, titulo: 'La Sombra del Viento',   autor: 'Carlos Ruiz Zafón',        genero: 'Misterio',    anio: 2001 },
  { id: 7, titulo: 'Sapiens',                autor: 'Yuval Noah Harari',        genero: 'No Ficción',  anio: 2011 },
  { id: 8, titulo: 'El Alquimista',          autor: 'Paulo Coelho',             genero: 'Ficción',     anio: 1988 },
  { id: 9, titulo: 'Ficciones',              autor: 'Jorge Luis Borges',        genero: 'Cuentos',     anio: 1944 },
  { id:10, titulo: 'Crimen y Castigo',       autor: 'Fyodor Dostoevski',        genero: 'Clásico',     anio: 1866 },
];

// ──────────────────────────────────────────────
// GET /api/libros?q=texto&genero=X
// ──────────────────────────────────────────────
app.get('/api/libros', (req, res) => {
  const { q = '', genero = '' } = req.query;

  let resultado = libros;

  if (q.trim()) {
    const term = q.trim().toLowerCase();
    resultado = resultado.filter(libro =>
      libro.titulo.toLowerCase().includes(term) ||
      libro.autor.toLowerCase().includes(term)
    );
  }

  if (genero.trim()) {
    resultado = resultado.filter(libro =>
      libro.genero.toLowerCase() === genero.trim().toLowerCase()
    );
  }

  res.json({
    total: resultado.length,
    query: { q, genero },
    data: resultado,
  });
});

// GET /api/libros/:id
app.get('/api/libros/:id', (req, res) => {
  const libro = libros.find(l => l.id === Number(req.params.id));
  if (!libro) return res.status(404).json({ error: 'Libro no encontrado' });
  res.json(libro);
});

// Health check
app.get('/health', (_req, res) => res.json({ status: 'ok', timestamp: new Date() }));

app.listen(PORT, () => {
  console.log(`✅ API Express corriendo en http://localhost:${PORT}`);
  console.log(`   Ejemplo: http://localhost:${PORT}/api/libros?q=sol`);
});
