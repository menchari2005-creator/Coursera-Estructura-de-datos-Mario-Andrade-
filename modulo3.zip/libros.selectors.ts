// ============================================================
// src/app/store/libros.selectors.ts
// NgRx Selectors
// ============================================================
import { createSelector, createFeatureSelector } from '@ngrx/store';
import { LibrosState } from './libros.reducer';

export const selectLibrosState = createFeatureSelector<LibrosState>('libros');

export const selectLeerAhora = createSelector(
  selectLibrosState,
  (state) => state.leerAhora
);
