// ============================================================
// src/app/app.config.ts
// Configuración de la aplicación Angular standalone
// ============================================================
import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideStore } from '@ngrx/store';

import { routes } from './app.routes';
import { librosReducer } from './store/libros.reducer';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(),
    // NgRx Store con la feature 'libros'
    provideStore({ libros: librosReducer }),
  ],
};
