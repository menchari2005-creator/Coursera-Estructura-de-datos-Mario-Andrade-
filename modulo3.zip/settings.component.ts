// ============================================================
// src/app/pages/settings/settings.component.ts
// Sección Settings — editar nombre de usuario (LocalStorage)
// ============================================================
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SettingsService } from '../../core/services/settings.service';
import { AppSettings } from '../../core/app-settings';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
})
export class SettingsComponent implements OnInit {

  username = '';
  apiUrl = AppSettings.API_URL;
  guardado = false;

  constructor(private settingsService: SettingsService) {}

  ngOnInit(): void {
    this.username = this.settingsService.username;
  }

  guardar(): void {
    this.settingsService.guardarUsername(this.username.trim());
    this.guardado = true;
    setTimeout(() => (this.guardado = false), 2500);
  }
}
