// ============================================================
// src/app/pages/home/home.component.ts
// Pantalla principal: búsqueda + lista "Leer Ahora" desde Redux
// ============================================================
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import { LibrosService, Libro } from '../../core/services/libros.service';
import { FavoritosService } from '../../core/services/favoritos.service';
import { SettingsService } from '../../core/services/settings.service';
import { selectLeerAhora } from '../../store/libros.selectors';
import { quitarLeerAhora } from '../../store/libros.actions';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {

  // Búsqueda
  query = '';
  resultados: Libro[] = [];
  cargando = false;
  error = '';
  buscado = false;

  // Redux: lista "Leer Ahora"
  leerAhora$: Observable<Libro[]>;

  // Usuario
  username$;

  constructor(
    private librosService: LibrosService,
    private favoritosService: FavoritosService,
    private settingsService: SettingsService,
    private store: Store
  ) {
    this.leerAhora$ = this.store.select(selectLeerAhora);
    this.username$ = this.settingsService.username$;
  }

  ngOnInit(): void {
    this.buscar(); // Carga inicial
  }

  buscar(): void {
    this.cargando = true;
    this.error = '';
    this.buscado = true;

    this.librosService.buscar(this.query).subscribe({
      next: (res) => {
        this.resultados = res.data;
        this.cargando = false;
      },
      error: (err) => {
        this.error = 'No se pudo conectar al servidor. Verifica la URL en AppSettings.';
        this.cargando = false;
        console.error(err);
      },
    });
  }

  toggleFavorito(libro: Libro): void {
    this.favoritosService.toggleFavorito(libro);
  }

  esFavorito(id: number): boolean {
    return this.favoritosService.esFavorito(id);
  }

  quitarDeLeerAhora(id: number): void {
    this.store.dispatch(quitarLeerAhora({ id }));
  }

  onEnter(event: KeyboardEvent): void {
    if (event.key === 'Enter') this.buscar();
  }
}
